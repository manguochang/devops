<html>
  	<?php echo "Hello world from a php container" ?>
</html>
